<?php

declare(strict_types=1);


class Uzytkownik
{

    /** @var Profil */
    private Profil $profil;

    /**
     * Default constructor
     */
    public function __construct()
    {
        // ...
    }

    /**
     * 
     */
    public function Uzytkownik()
    {
        // TODO implement here
    }

    /**
     * @return PowiadomieniaEmail
     */
    public function pobierzPowiadomienieEmail(): PowiadomieniaEmail
    {
        // TODO implement here
        return null;
    }

}

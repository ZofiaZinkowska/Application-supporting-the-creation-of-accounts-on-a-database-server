<?php

declare(strict_types=1);


class EdycjaProfilu
{

    /** @var Uzytkownik */
    private Uzytkownik $uzytkownik;

    public  $Attribute1;

    /**
     * Default constructor
     */
    public function __construct()
    {
        // ...
    }

    /**
     * @return void
     */
    public function zmienHaslo(): void
    {
        // TODO implement here
        return null;
    }

    /**
     * @return void
     */
    public function zmienEmail(): void
    {
        // TODO implement here
        return null;
    }

    /**
     * @return void
     */
    public function zmienNazwaUzytkownika(): void
    {
        // TODO implement here
        return null;
    }

    /**
     * @return void
     */
    public function usunKonto(): void
    {
        // TODO implement here
        return null;
    }

}

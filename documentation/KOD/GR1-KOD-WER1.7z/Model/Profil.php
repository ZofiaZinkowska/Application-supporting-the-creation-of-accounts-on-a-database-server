<?php

declare(strict_types=1);


class Profil
{

    /** @var string */
    private string $email;

    /** @var string */
    private string $nazwaUzytkownika;

    /** @var string */
    private string $haslo;

    /** @var boolean */
    private boolean $statusZalogowania;

    /**
     * Default constructor
     */
    public function __construct()
    {
        // ...
    }

    /**
     * @return void
     */
    protected function zarejestruj(): void
    {
        // TODO implement here
        return null;
    }

    /**
     * @return void
     */
    protected function zaloguj(): void
    {
        // TODO implement here
        return null;
    }

    /**
     * @return void
     */
    protected function wyloguj(): void
    {
        // TODO implement here
        return null;
    }

    /**
     * @return void
     */
    protected function ustawEmail(): void
    {
        // TODO implement here
        return null;
    }

    /**
     * @return void
     */
    protected function ustawNazwaUzytkownika(): void
    {
        // TODO implement here
        return null;
    }

    /**
     * @return void
     */
    protected function ustawHaslo(): void
    {
        // TODO implement here
        return null;
    }

}

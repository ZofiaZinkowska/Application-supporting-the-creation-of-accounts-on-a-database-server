<?php

declare(strict_types=1);


class Login
{

    /** @var List<Profil> */
    private List<Profil> $listaProfil;

    /**
     * Default constructor
     */
    public function __construct()
    {
        // ...
    }

    /**
     * @return List<Login>
     */
    public function generujLoginy(): List<Login>
    {
        // TODO implement here
        return null;
    }

}

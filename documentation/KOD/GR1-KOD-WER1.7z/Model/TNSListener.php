<?php

declare(strict_types=1);


class TNSListener
{

    /** @var boolean */
    private boolean $statusTNS;

    /**
     * Default constructor
     */
    public function __construct()
    {
        // ...
    }

    /**
     * 
     */
    public function TNSListener()
    {
        // TODO implement here
    }

    /**
     * @return void
     */
    public function spawdzUslugeTNS(): void
    {
        // TODO implement here
        return null;
    }

    /**
     * @return boolean
     */
    public function pobierzStatusTNS(): boolean
    {
        // TODO implement here
        return false;
    }

    /**
     * @return void
     */
    public function ustawStatusTNS(): void
    {
        // TODO implement here
        return null;
    }

}

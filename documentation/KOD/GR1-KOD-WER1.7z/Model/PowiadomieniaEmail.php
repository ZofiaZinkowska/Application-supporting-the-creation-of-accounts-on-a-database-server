<?php

declare(strict_types=1);


class PowiadomieniaEmail
{

    /**
     * Default constructor
     */
    public function __construct()
    {
        // ...
    }

    /**
     * 
     */
    public function PowiadomieniaEmail()
    {
        // TODO implement here
    }

    /**
     * @return List<Uzytkownik>
     */
    public function wyslijListeUzytkownikowDoAnalizy(): List<Uzytkownik>
    {
        // TODO implement here
        return null;
    }

    /**
     * @return void
     */
    public function pobierzListeUzytkownikowDoAnalizy(): void
    {
        // TODO implement here
        return null;
    }

}

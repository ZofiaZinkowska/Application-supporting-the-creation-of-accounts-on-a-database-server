<?php

declare(strict_types=1);


class PlikZUzytkownikami
{

    /** @var [object Object] */
    private Uzytkownik $uzytkownik;

    /**
     * Default constructor
     */
    public function __construct()
    {
        // ...
    }

    /**
     * 
     */
    public function plikUzytkownikow()
    {
        // TODO implement here
    }

    /**
     * @return void
     */
    public function dodajUzytkownikaDoPliku(): void
    {
        // TODO implement here
        return null;
    }

    /**
     * @return List<Uzytkownik>
     */
    public function wczytajUzytkownikowZPliku(): List<Uzytkownik>
    {
        // TODO implement here
        return null;
    }

    /**
     * @return void
     */
    public function zapiszUzytkownikowDoPliku(): void
    {
        // TODO implement here
        return null;
    }

    /**
     * @return List<Uzytkownik>
     */
    public function generujListeUzytkownikowDoAnalizy(): List<Uzytkownik>
    {
        // TODO implement here
        return null;
    }

}

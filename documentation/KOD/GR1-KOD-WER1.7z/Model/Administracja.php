<?php

declare(strict_types=1);


class Administracja
{

    /** @var [object Object] */
    private Profil $profil;

    /** @var TNSListener */
    private TNSListener $tnsListener;

    /**
     * Default constructor
     */
    public function __construct()
    {
        // ...
    }

    /**
     * 
     */
    public function Administrator()
    {
        // TODO implement here
    }

    /**
     * @return void
     */
    public function usunKontoZBazDanych(): void
    {
        // TODO implement here
        return null;
    }

    /**
     * @return void
     */
    public function zwiekszQuoteUzytkownik(): void
    {
        // TODO implement here
        return null;
    }

    /**
     * @return void
     */
    public function zalozKontoZPliku(): void
    {
        // TODO implement here
        return null;
    }

    /**
     * @return Konto
     */
    public function dodajKontoDoBazyDanych(): Konto
    {
        // TODO implement here
        return null;
    }

    /**
     * @return boolean
     */
    public function sprawdzStanKontaUzytkownika(): boolean
    {
        // TODO implement here
        return false;
    }

}
